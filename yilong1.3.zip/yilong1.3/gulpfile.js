const gulp = require('gulp');//引入gulp模块
const cleanCSS = require('gulp-clean-css');//压缩css文件
const concatJS = require('gulp-concat');//合并js文件
const uglifyJS = require('gulp-uglify');//压缩js文件
const cleanImg = require('gulp-imagemin');//压缩图片


//编写任务
gulp.task('task1',function(){
	console.log('hello ,gulp');
});
// 将编译好的css,压缩
gulp.task('mincss',function(){
	gulp.src('src/css/*.css')
		.pipe(cleanCSS())
		.pipe(gulp.dest('dest/css'))
});
//合并压缩js文件
gulp.task('concatminjs',function(){
	gulp.src('src/js/*.js')
		.pipe(concatJS('yilong.min.js'))//参数为合并之后的文件名
		.pipe(uglifyJS())
		.pipe(gulp.dest('dest/js'))
});
//压缩图片
gulp.task('minimg',function(){
	gulp.src('src/img/xianshi/*.{png,jpg}')
		.pipe(cleanImg())
		.pipe(gulp.dest('dest/img/xianshi'))
});


